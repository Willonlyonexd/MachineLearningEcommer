# Configuración de conexión a la base de datos de MongoDB

DB_MONGO = {
    "uri": "mongodb+srv://houwenvt:will@cluster0.crz8eun.mongodb.net/EcommerTenants",
    "db_name": "EcommerTenants"
}